<template>
    <div class="container mx-auto p-4">

      <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
        <!-- Card 1 -->
        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profileman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Syafie Nazmi</h2>
            <p class="text-gray-600">This is a brief description of the card content.</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >Entertaining event for family..</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="@/assets/images/rating/5star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >132764</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>
  
        <!-- Repeat Card for Multiple Items -->
        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profileman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Brandon Choo</h2>
            <p class="text-gray-600">School of Physics</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >An entertaining show yet still can be improved.</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="@/assets/images/rating/4star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >134687</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>
        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profilewoman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Huda Nabilah </h2>
            <p class="text-gray-600">School of Mathematical Science</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >Lots of cultural dance and amazing performance..</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="../assets/images/rating/5star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >163947</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>

        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profileman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Edu Sinusi </h2>
            <p class="text-gray-600">School of Chemistry</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >Various and unique costume and beautiful performers.</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="../assets/images/rating/4star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >163947</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>

        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profileman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Abdul Qayyum </h2>
            <p class="text-gray-600">School of Art Science</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >Celebrities hyped the event much more..</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="../assets/images/rating/5star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >132476</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>

        <div class="bg-white border rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
          <img src="../assets/images/profile/profilewoman.png" alt="Card Image" class="w-full h-80 w-30 object-cover">
          <div class="p-4">
            <h2 class="text-xl font-bold mb-2">Michelle Ling </h2>
            <p class="text-gray-600">School of Architecture</p>
            <h2 class="text-xl font-bold mb-2">Comment</h2>
            <p class="text-gray-600 mb-2" >Beautiful decoration of venue.</p>
            <div class="row">
            <h2 class="text-xl font-bold mt-2">Rating</h2>
            <img  style="max-width:80px;" src="../assets/images/rating/5star.png" alt="Country flag" />
        </div>
        <h2 class="text-xl font-bold mb-2">Ticket ID</h2>
        <p class="text-gray-600 mb-2" >132475</p>
          </div>
          <div class="p-4">
            <button class="w-full bg-pink-500 text-white py-2 rounded-md hover:bg-blue-600">
              Learn More
            </button>
          </div>
        </div>

  
      </div>
    </div>
  </template>
  
  <style scoped >
  @import "tailwindcss/base";
@import "tailwindcss/components";
@import "tailwindcss/utilities";
  body {
    background-color: #f9fafb;
  }
  </style>
  