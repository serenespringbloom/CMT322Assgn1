<template>
    <div>
      <h1>Admin Information</h1>
      <p><strong>Name:</strong> admin</p>
      <p><strong>Role:</strong> admin</p>
    </div>
</template>