<script setup>

import CardContainer from "../components/CardContainer.vue";
</script>
<template>
  <div class="py-1 container-fluid">
    <div style="background-image: linear-gradient(to right, rgba(164, 142, 105, 1), rgba(220, 195, 156, 1));margin-top: 5px;"
      >
     
      <div style="background-image: linear-gradient(to right, rgba(164, 142, 105, 1), rgba(220, 195, 156, 1));" 
      class="text-white p-4 text-xl font-bold flex item-center justify-center">
         <h2>Feedback</h2> 
        </div>
      </div>
   
    <CardContainer/>
    
  
  </div>
</template>

<style scoped>
@import "tailwindcss/base";
@import "tailwindcss/components";
@import "tailwindcss/utilities";
</style>
